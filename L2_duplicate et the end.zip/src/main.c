#pragma interrupt INTIT r_it_interrupt
#include "r_macro.h"  /* System macro and standard type definition */
#include "showLCD.h"
#include "SW.h"
#include "api.h"
	
/******************************************************************************
Macro definitions
******************************************************************************/
/******************************************************************************
Typedef definitions
******************************************************************************/
typedef struct {
	int minute;
	int second;
	int centi;
} time_t;

/******************************************************************************
Imported global variables and functions (from other files)
******************************************************************************/
extern char status;
extern int matchtime;
extern char* stringtime[10];
extern char ch;
extern int matchtime;
extern int recordflag;
extern int timesave;
extern volatile int G_elapsedTime;   // Timer Counter

/******************************************************************************
Exported global variables and functions (to be accessed by other files)
******************************************************************************/
void scrollfunction() ;
void resetall();

/******************************************************************************
Private global variables and functions
******************************************************************************/
time_t curr, prev[19];
char* stringrecord[12];
int line;
int lineNo;
int recordNo;
int recordIndex;int recordcount;
int show2scount;
int scrollcount;
int recordshowcount;
int i;

/******************************************************************************
* Function Name: main
* Description  : Main program
* Arguments    : none
* Return Value : none
******************************************************************************/
void main() {
	r_main_userinit();
	R_IT_Create();
	R_IT_Start();
	LCD_reset();
	recordflag = 0;
	status = 'p';
	/* Infinit loop */
	while (1U){
		switch (status)	{
		case 'p' :
				/* show Pausing... again afer 2 second */
				if (G_elapsedTime >= 200) {
					DisplayLCD(LCD_LINE1,(unsigned char *)"Pausing...");
					G_elapsedTime = 0;
				}
				/* polling switchs */	
				sw1sw2function();
				timesave = G_elapsedTime;
				if (pollingSW3())
					{
					status = 'r';
					DisplayLCD(LCD_LINE1,(unsigned char *)"Running...");
					delay_10CentiS();
					}
				break;
		case 'r' :
				delay_10CentiS();
				/* show Running... again afer 2 second */
				if (show2scount >= 2) {
					DisplayLCD(LCD_LINE1,(unsigned char *)"Running...");
					show2scount = 0;
				}
				/* couting time and print on the second line */
				if (G_elapsedTime >= (curr.centi + 10)) {
					curr.centi = (curr.centi + 10);
					if (G_elapsedTime >= 100) {
						curr.second ++;							
						show2scount++;
						G_elapsedTime = 0;
						curr.centi = 0;
					}
					if (curr.second >= 59) {
						curr.minute++;
						curr.second = 0;
					}
					if (curr.minute >= 99) {
						curr.minute = 0;
					}
					sprintf(stringtime, "%d:%d:%d      ",curr.minute, curr.second, curr.centi);
					show_LCD(LCD_LINE2, stringtime);
				}
					
				/* polling switchs */		
				sw1sw2function();
				if (pollingSW3()) {
					if (recordcount < 20)
						recordcount++;
					if (scrollcount <= recordcount - 7)
						scrollcount++;
					/* set last record */
					prev[recordcount-1].centi = curr.centi;
					prev[recordcount-1].second = curr.second;
					prev[recordcount-1].minute = curr.minute;
					
					/*print record from No1 to record No6 */
					if (recordcount < 6) {
								
						for (recordNo = recordcount; recordNo >= 1 ; recordNo--) {
							recordIndex = recordNo - 1;
							lineNo = LCD_LINE2 + recordNo*8;
							sprintf(stringtime, "#%d:%d:%d:%d   ",recordNo, prev[recordIndex].minute, prev[recordIndex].second, prev[recordIndex].centi);
							show_LCD(lineNo, stringtime);
						}
					/*print record from last record-6 to last record */
					} else {
							
						
					
						for (i = 0; i < 6; i++) {
							recordNo = recordcount - i;
							recordIndex = recordcount - i - 1;
							lineNo = LCD_LINE8 - i*8;
							sprintf(stringtime, "#%d:%d:%d:%d  ",recordNo, prev[recordIndex].minute, prev[recordIndex].second, prev[recordIndex].centi);
							show_LCD(lineNo, stringtime);
						}
					}
					delay_10CentiS();
					
					if (recordcount >= 20) {
						/* loop to move record */
						for (recordNo = 1 ; recordNo < recordcount; recordNo++){
							recordIndex = recordNo - 1;
							prev[recordNo-1].centi = prev[recordNo].centi;
							prev[recordNo-1].second = prev[recordNo].second;
							prev[recordNo-1].minute = prev[recordNo].minute;
						}	
					}
				}
				if (recordcount > 0) { 
					recordflag = 1;
				} else {
					recordflag = 0;
				}
				break;
		default :
				break;
		}
	}
}

/******************************************************************************
* Function Name: scrollfunction
* Description  : This function is use to scroll up or down
* Arguments    : none
* Return Value : none
******************************************************************************/
void scrollfunction() 
{	
	if (pollingSW1()) {
					
					
			if (!recordflag) {
				DisplayLCD(LCD_LINE1,(unsigned char *)"No record");
			} else {
				
				if (scrollcount >=1) {
						scrollcount--;	
						/*print record from [scrollcount] to [scrollcount+6] */
						for (i = 1; i <= 6; i++) {
							recordNo = i + scrollcount;
							recordIndex = i + scrollcount - 1;
							lineNo = i*8+ LCD_LINE2;
							sprintf(stringtime, "#%d:%d:%d:%d  ",recordNo, prev[recordIndex].minute, prev[recordIndex].second, prev[recordIndex].centi);
							show_LCD(lineNo, stringtime);
						}
				} else {
					show2scount = 0;
					DisplayLCD(LCD_LINE1,(unsigned char *)"First record");
				}
			}
	}			
	if (pollingSW2()) {
			if (!recordflag) {
				DisplayLCD(LCD_LINE1,(unsigned char *)"No record");
			} else {
				if (scrollcount <= recordcount - 7) {
						scrollcount++;	
						/*print record from [scrollcount] to [scrollcount+6] */
						for (i = 1; i <= 6; i++) {
							recordNo = i + scrollcount;
							recordIndex = i + scrollcount - 1;
							lineNo = i*8+ LCD_LINE2;
							sprintf(stringtime, "#%d:%d:%d:%d  ",recordNo, prev[recordIndex].minute, prev[recordIndex].second, prev[recordIndex].centi);
							show_LCD(lineNo, stringtime);
						}
				} else {
					show2scount = 0;
					DisplayLCD(LCD_LINE1,(unsigned char *)"Last record");
				}
			}
	}
}

/******************************************************************************
* Function Name: resetall
* Description  : this function is used to reset the time count
* Arguments    : none
* Return Value : none
******************************************************************************/
void resetall() 
{
	LCD_reset();
	recordflag = 0;
	show2scount = 0;
	recordshowcount = 0;
	recordcount = 0;
	curr.minute = 0;
	curr.second = 0;
	curr.centi = 0;
	for (recordNo = 1 ; recordNo < recordcount; recordNo++){
		prev[recordNo-1].centi = 0;
		prev[recordNo-1].second = 0;
		prev[recordNo-1].minute = 0;
	}
}

__interrupt static void r_it_interrupt(void)
{
    /* Start user code. Do not edit comment generated here */
    G_elapsedTime++;
    /* End user code. Do not edit comment generated here */
}
/******************************************************************************
End of file
******************************************************************************/
